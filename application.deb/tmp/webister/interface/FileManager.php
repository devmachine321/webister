<?php include("include/head.php"); ?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">

						<h2 class="page-title">File Manager</h2>
						<iframe src="fman/elfinder.src.html" width="1000px" height="500px"></iframe>


<?php include("include/footer.php"); ?>
