import py_compile
py_compile.compile('python/main.py')
py_compile.compile('python/server.py')
