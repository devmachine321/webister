<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Webister Web Hosting Home</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/slider.css" rel="stylesheet" type="text/css" media="all"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,600,700,400' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/jquery.easydropdown.js"></script>
<script type="text/javascript" src="js/script.js"></script>
 <script type="text/javascript" src="js/jquery.nivo.slider.js"></script>
 <script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
 <link href="css/magnific-popup.css" rel="stylesheet" type="text/css">
 <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();
    });
    </script>    
</head>
<body>
  <div class="header" id="home">
  	  <div class="header_top">
	   <div class="wrap">
		 	     <div class="logo">
						<h1 style="color:white;">Tecflare</h1>
					</div>	
						<div class="menu">
						    <ul>
						    
								<li class="login" >
									<div id="loginContainer">
						                <div id="loginBox">                
						                    <form id="loginForm">
						                        <fieldset id="body">
						                        	 <fieldset>
						                                <label for="email">User Name</label>
						                                <input type="text" value="">
						                            </fieldset>
						                            <fieldset>
						                                <label for="email">Email Address</label>
						                                <input type="text" value="">
						                            </fieldset>
						                            <fieldset>
						                                <label for="password">Password</label>
						                                <input type="password" value="">
						                            </fieldset>
						                            <fieldset>
						                                <label for="password">Confirm Password</label>
						                                <input type="password" value="">
						                            </fieldset>
						                            <input type="submit" id="login" value="Sign Up">
						                            <label for="checkbox"><input type="checkbox"> <i>T & C apply</i></label>
						                        </fieldset>
						                        <span><a href="#">Already do u have an account ?</a></span>
						                    </form>
						                </div>
						               </div>
								   </li>
								<div class="clear"></div>
							</ul>
						</div>							
	    		 <div class="clear"></div>
	        </div>
	    </div>
	 </div>			      	
     <div class="main" id="container">
	 	<div class="content">	
	 		 <div class="content_top section" id="section-1">  
	 		     <div class="wrap">                                  		
            	   <div class="banner_desc">
            	      <div class="wmuSlider example1">
							<div class="wmuSliderWrapper">
							<article><p>Find the right cloud Hosting Without the Fluffy  white stuff</p> <img src="images/clouds.png"  alt="" /> </article>
							<article><p>Lorem ipsum dolor sit amet elit dolore magna aliqua</p> <img src="images/system.png"  alt="" /> </article>
							<article><p>Duis aute irure dolor in velit esse cillum dolore labore et dolore</p> <img src="images/slider-img3.png"  alt="" /> </article>
							<article><p>Sed do eiusmod tempor labore et dolore magna aliqua</p> <img src="images/slider-img4.png"  alt="" /> </article>
							</div>
                       </div>
            	      <script src="js/jquery.wmuSlider.js"></script> 
						<script type="text/javascript" src="js/modernizr.custom.min.js"></script> 
						<script>
       						 $('.example1').wmuSlider();         
   						 </script> 	   
   						         	      
            			
                 	
        	
     		 </div>
                       </div>
           <div class="about_desc section" id="section-2"> 
              <div class="wrap">            
                 	<div class="section group example">
						<div class="col_1_of_2 span_1_of_2">
						   <h3>We use 100% Real Clouds</h3>
						   <p><span>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in aliquip ex ea commodo consequat.</span></p>
						   <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat in voluptate velit esse cillum dolore eu fugiat.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Duis aute irure dolor in dolore eu fugiat in voluptate velit esse cillum dolore eu fugiat.</p>

		 				</div>
						<div class="col_1_of_2 span_1_of_2">
						<h3>$0.00</h3>
						<p>1 Database</p>
						<p>100MB disk space</p>
						<a href="<?php $actual_link = 'http://'.$_SERVER['HTTP_HOST'];echo $actual_link; ?>:8081/gen.php?id=dfkjstijijf">Pay Now</a>
						  </div>
				    </div>	        
           	  </div>             
       	  </div>  
       	  
       	    <div class="features section" id="section-3">      	      	      	   	
       	   	 	<h2>How it Works</h2>
       	   
       	    <!------ Slider ------------>	 
       	    <div class="browser">  	       
       	   	    <div id="mySliderTabsContainer">
	               <div id="mySliderTabs">
	               <ul>
	                <li><a class="cloud_icon" href="#mother"><i class="cloud_icon"> </i></a></li>
	                <li><a class="cross" href="#parks">  <i class="cross"> </i> </a></li>
	                <li><a class="bubble" href="#theOffice"><i class="bubble"> </i></a></li>
	                <li><a class="right_arrow" href="#southPark"> <i class="right_arrow"> </i></a></li>
	              </ul>
	              <div id="mother">
	              	<img src="images/browser1.png" alt="" />
	              </div>
	              <div id="parks">
	                 <img src="images/browser2.png" alt="" />
	              </div>
	              <div id="theOffice">
	              	<img src="images/browser3.png" alt="" />
	              </div>
	              <div id="southPark">
	              	<img src="images/browser4.png" alt="" />
	              </div>             
	            </div>
	            <div class="clear"></div>
	          </div>
          </div>
            <link rel="stylesheet" href="css/jquery.sliderTabs.min.css">
			<script src="js/jquery.sliderTabs.min.js"></script> 
			<script>
				 $(document).ready(function(){
				      var tabs = $("div#mySliderTabs").sliderTabs({
				        autoplay:5000,
				        indicators: true,
				        panelArrows: true,
				        panelArrowsShowOnHover: true
				      });      
				/*      $("#mySliderTabsContainer").resizable({
				        maxHeight: 200,
				        minHeight: 200,
				        maxWidth: 605
				      });
				*/
				      prettyPrint();
				    });
				
				    $(document).delegate(".nav-list li a", "click", function(){
				      $(this).parent().siblings().removeClass("active");
				      $(this).parent().addClass("active");
				    });	
			</script>
		    <!------End Slider ------------>
       	   </div>  
       	 </div>
      </div>
     <div class="footer section"  id="section-4">
     	 <div class="wrap">
     	 	    
     		</div>
     		<div class="copy-right">
			<div class="wrap">
				<p class="copy">© 2013 Template by <a href="http://w3layouts.com" target="_blank">w3layouts</a> Powered by Webister </p>
			</div>
	  </div>       
   
	</body>
</html>

