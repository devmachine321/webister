#flinstall support
sudo ./build
echo "Continue Install"
exit 0