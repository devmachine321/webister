<?php
include("/var/webister/interface/config.php");
echo $pass;
?>