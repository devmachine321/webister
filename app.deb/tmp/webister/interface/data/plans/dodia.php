<?php
$name = "dodia";
$disk = "100";
$pstart = "1000";
$pend = "5000";
$cost = "9.99";
?>