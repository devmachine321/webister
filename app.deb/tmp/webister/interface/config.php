<?php
$host="localhost";
$user="root";
$pass="test";
$data = "webister";
?>