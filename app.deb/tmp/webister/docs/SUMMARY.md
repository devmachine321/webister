

# Table of content

* [Installation](docs/getting-started.md)
* [First Time Setup](docs/setup.md)
